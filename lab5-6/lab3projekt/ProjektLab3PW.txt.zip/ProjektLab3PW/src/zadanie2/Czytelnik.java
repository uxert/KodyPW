package zadanie2;

import java.util.concurrent.Semaphore;


public class Czytelnik extends Thread{

    Semaphore czyt;
    Semaphore pis;
    Semaphore chron;
    int nr_czytelnika;
    int liczba_powtorzen;

    int[] l;
    public Czytelnik(int nr, Semaphore[] sems, int liczba_powtorzen, int[] liczby)
    {
        nr_czytelnika = nr;
        czyt = sems[0];
        pis = sems[1];
        chron = sems[2];
        this.liczba_powtorzen = liczba_powtorzen;
        this.l = liczby;
    }

    void sprawyWlasne() {
        try {
            Thread.sleep((long) (5 + Math.random() * 10));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    void czytanie()
    {
        try {
            Thread.sleep((long) (1 + Math.random() * 4));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    void dzialanieCzytelnika() throws InterruptedException {
        for (int count = 0; count < liczba_powtorzen; count++)
        {

            //wlanse sprawy

            chron.acquire();
            System.out.printf(">>> [C-%d, %d] :: [%d %d %d %d]\n", nr_czytelnika + 1, count + 1, l[1], l[0], l[3], l[2]);
            if ((l[2] + l[3]) == 0)
            {
                l[1] ++;
                czyt.release();
            }
            else
            {
                l[0]++;
            }
            System.out.printf("<<< [C-%d, %d] :: [%d %d %d %d]\n", nr_czytelnika + 1, count + 1, l[1], l[0], l[3], l[2]);

            chron.release();

            czyt.acquire();
            //czytanie
            System.out.printf("==> [C-%d, %d] :: [%d %d %d %d]\n", nr_czytelnika + 1, count + 1, l[1], l[0], l[3], l[2]);
            czytanie();
            System.out.printf("<== [C-%d, %d] :: [%d %d %d %d]\n", nr_czytelnika + 1, count + 1, l[1], l[0], l[3], l[2]);


            chron.acquire();
            System.out.printf(">>> [C-%d, %d] :: [%d %d %d %d]\n", nr_czytelnika + 1, count + 1, l[1], l[0], l[3], l[2]);

            l[1]--;
            if (l[1] == 0)
            {
                if (l[2] > 0)
                {
                    l[3] = 1;
                    l[2]--;
                    pis.release();
                }
            }
            System.out.printf("<<< [C-%d, %d] :: [%d %d %d %d]\n", nr_czytelnika + 1, count + 1, l[1], l[0], l[3], l[2]);

            chron.release();
        }

    }
    public void run() {
        try {
            dzialanieCzytelnika();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

}
