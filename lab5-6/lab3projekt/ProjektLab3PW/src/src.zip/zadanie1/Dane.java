package zadanie1;

public class Dane {
    final int N;
    String[] buf;
    int j;
    int k;

    public Dane(final int N)
    {
        this.N = N;
        this.buf = new String[N];
        this.j = 1;
        this.k = 1;
    }

}
